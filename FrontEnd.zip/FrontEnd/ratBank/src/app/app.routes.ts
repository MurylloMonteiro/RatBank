import { Routes } from '@angular/router';
import { Login } from './pages/login/login';
import { Home } from './pages/home/home';
import { PixArea } from './pages/pix-area/pix-area';
import { Register } from './pages/register/register';
import { PixTransfer } from './pages/pix-transfer/pix-transfer';
import { DepositArea } from './pages/deposit-area/deposit-area';

export const routes: Routes = [
    {path: "", component:Login},
    {path: "home", component:Home},
    {path: "pix-area", component:PixArea},
    {path: "pix-transfer", component:PixTransfer},
    {path: "deposit-area", component:DepositArea},
    {path: "register", component:Register},
    {path: "**", redirectTo: '/'}
];
