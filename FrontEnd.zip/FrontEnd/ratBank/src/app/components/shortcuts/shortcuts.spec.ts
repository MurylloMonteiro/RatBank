import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Shortcuts } from './shortcuts';

describe('Shortcuts', () => {
  let component: Shortcuts;
  let fixture: ComponentFixture<Shortcuts>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Shortcuts]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Shortcuts);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
