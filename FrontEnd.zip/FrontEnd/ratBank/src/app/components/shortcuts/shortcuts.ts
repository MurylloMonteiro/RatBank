import { Component } from '@angular/core';
import { RouterLink } from "@angular/router";

@Component({
  selector: 'app-shortcuts',
  imports: [RouterLink],
  templateUrl: './shortcuts.html',
  styleUrl: './shortcuts.css',
})
export class Shortcuts {

}
