import { Component, OnInit } from '@angular/core';
import { BalanceService } from '../../services/balance-service';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-balance',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './balance.html',
  styleUrl: './balance.css',
})
export class Balance implements OnInit {

  balance!: number;

  constructor(private balanceS: BalanceService) { }

  ngOnInit(): void {
    this.balance = 0;
    this.buscarSaldo();
    var SessionUserInfo = JSON.parse(sessionStorage.getItem("User")!);
    this.balance = SessionUserInfo.balance;

  }

  buscarSaldo() {
    this.balanceS.BalanceInfo().subscribe({
      next: (res) => {
        if (res.status === 202) {
          sessionStorage.setItem("User", JSON.stringify(res.body));
        } else {
          console.log("conta não encontrada");
        }

      }, error: err => {
        console.log(err + " enfrentamos instabilidade");
      }
    })
  }
}


