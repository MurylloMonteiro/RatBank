import { Component } from '@angular/core';

@Component({
  selector: 'app-pix-keys',
  imports: [],
  templateUrl: './pix-keys.html',
  styleUrl: './pix-keys.css',
})
export class PixKeys {
  infos: any = JSON.parse(sessionStorage.getItem("User")!);

  pixKey: any = this.infos.pixKey;

}
