import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PixKeys } from './pix-keys';

describe('PixKeys', () => {
  let component: PixKeys;
  let fixture: ComponentFixture<PixKeys>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PixKeys]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PixKeys);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
