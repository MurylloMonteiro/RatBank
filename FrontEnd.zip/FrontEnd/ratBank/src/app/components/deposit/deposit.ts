import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { DepositService } from '../../services/deposit-service';
import { Router } from '@angular/router';  
@Component({
  selector: 'app-deposit',
  imports: [ReactiveFormsModule],
  templateUrl: './deposit.html',
  styleUrl: './deposit.css',
})
export class Deposit implements OnInit{

  value!: number;

  constructor(
    private router: Router,
    private depositService: DepositService
  ){}


  ngOnInit(): void {
    this.value = 0;

    var info = JSON.parse(sessionStorage.getItem("User")!)

    this.value = info.balance
  }

  depositForm = new FormGroup({
    value: new FormControl(0, Validators.required)
  })

  depoistAccount(){

    this.depositService.depoist(this.depositForm.value.value!).subscribe({
      next: res => {
        if(res.status === 200){
          console.log(res.status)
          this.router.navigateByUrl('/home')

        }
      }
    })

  }
}
