import { Component } from '@angular/core';
import { RouterLink } from "@angular/router";

@Component({
  selector: 'app-pix-send',
  imports: [RouterLink],
  templateUrl: './pix-send.html',
  styleUrl: './pix-send.css',
})
export class PixSend {

}
