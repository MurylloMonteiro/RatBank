import { HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoginRequest } from '../interfaces/login-request';
import { LoginResponse } from '../interfaces/login-response';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';



@Injectable({
  providedIn: 'root',
})
export class LoginService {

  constructor(
    private router: Router,
    private http: HttpClient

  ) { }


  login(email: String, password: String): any {

    const body: LoginRequest = {
      email: email,
      password: password
    }

    this.http.post<LoginResponse>(`${environment.apiUrl}/auth/login`, body, { observe: 'response' }).subscribe({
      next: (res) => {
        if(res.status === 202){
          this.router.navigateByUrl('/home')
          localStorage.setItem('token', res.body!.token);  
        }
      },
      error: (err) => {
        this.router.navigateByUrl('/')
      }
    })



  }



}
