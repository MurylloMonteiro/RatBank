import { TestBed } from '@angular/core/testing';

import { PixTransferService } from './pix-transfer-service';

describe('PixTransferService', () => {
  let service: PixTransferService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PixTransferService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
