import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { PixTransferInterface } from '../interfaces/pix-transfer-interface';

@Injectable({
  providedIn: 'root',
})
export class PixTransferService {

  constructor(
    private http: HttpClient
  ) { }


  pixTransfer(receivedPixKey: String, value: number) {
    var info = JSON.parse(sessionStorage.getItem("User")!);
    
    
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });

    const body: PixTransferInterface = {
      pixEnvoy: info.pixKey,
      pixReceived: receivedPixKey,
      value: value
    }

    return this.http.post(`${environment.apiUrl}/transation`, body, {headers, observe: 'response'}).subscribe({
      next: res => {
        console.log(res)
      }
    })
  }


}
