import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BalanceReponse } from '../interfaces/balance-reponse';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class BalanceService  {

  constructor(
    private http: HttpClient
  ) { }

  BalanceInfo(): Observable<HttpResponse<BalanceReponse>> {
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });

    return this.http.get<BalanceReponse>(`${environment.apiUrl}/account`, { headers, observe: 'response' })

  }
}
