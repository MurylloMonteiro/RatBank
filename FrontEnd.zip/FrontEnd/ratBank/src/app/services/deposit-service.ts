import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class DepositService {

  constructor(
    private http: HttpClient
  ) { }

  depoist(value: number) {
    var info = JSON.parse(sessionStorage.getItem("User")!);

    const token = localStorage.getItem('token');
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });

    const body = {
      "numberAccount": info.numberAccount,
      "value": value
    }

    return this.http.put(`${environment.apiUrl}/account/deposit`, body, {headers, observe: 'response'})
  }

}
