import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root',
})
export class CreateAccountService {


  constructor(
    private router: Router,
    private http: HttpClient
  ){}


  register(name: String, cpf: String, phoneNumber: String, email: String, password: String){

    const body: any = {
      name: name,
      cpf: cpf,
      phone_number: phoneNumber,
      email: email,
      password: password
    }

    this.http.post(`${environment.apiUrl}/auth/create-account`, body, { observe: 'response'}).subscribe({
      //nada por enquanto
    })


  }


}
