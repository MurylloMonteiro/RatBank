export interface PixTransferInterface {
    
    //user's PIX keys
    pixEnvoy: String;
    pixReceived: String;

    //Value
    value: number ;

}
