export interface BalanceReponse {
    balance: number,
    negativeBalance: number,
    numberAccount: String,
    pixKey: String,
    username: String
}
