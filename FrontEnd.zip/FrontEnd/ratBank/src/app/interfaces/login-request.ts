export interface LoginRequest {
    email: String;
    password: String;
    
}
