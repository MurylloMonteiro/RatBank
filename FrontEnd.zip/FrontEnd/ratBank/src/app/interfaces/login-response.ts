export interface LoginResponse {
    token: string;
}
