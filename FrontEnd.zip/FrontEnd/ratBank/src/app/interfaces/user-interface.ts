export interface UserInterface {
    id: number;
    email: String;
    name: String;
    numberAccount: String;
    token: String;
}
