import { Component } from '@angular/core';
import { Deposit } from "../../components/deposit/deposit";
import { Footer } from "../../components/footer/footer";

@Component({
  selector: 'app-deposit-area',
  imports: [Deposit, Footer],
  templateUrl: './deposit-area.html',
  styleUrl: './deposit-area.css',
})
export class DepositArea {

}
