import { Component } from '@angular/core';
import { LoginService } from '../../services/login-service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterLink } from "@angular/router";

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './login.html',
  styleUrl: './login.css',
})

export class Login {

  

  constructor( 
    private loginService: LoginService
  ) {}



  loginForm = new FormGroup({
    email: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
  })

   login(){

      this.loginService.login(this.loginForm.value.email!, this.loginForm.value.password!) 
    }

  
}

