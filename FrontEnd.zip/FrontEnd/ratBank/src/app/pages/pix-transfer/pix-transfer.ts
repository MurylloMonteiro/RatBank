import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { PixTransferService } from '../../services/pix-transfer-service';
import { Footer } from "../../components/footer/footer";

@Component({
  selector: 'app-pix-transfer',
  standalone: true,
  imports: [ReactiveFormsModule, Footer],
  templateUrl: './pix-transfer.html',
  styleUrl: './pix-transfer.css',
})
export class PixTransfer implements OnInit {

  constructor(private pixService: PixTransferService) {}

  pixTransferForm = new FormGroup({
    received: new FormControl('', [
      Validators.required,
      Validators.pattern(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/)
    ]),
    value: new FormControl(0, Validators.required)
  });

  ngOnInit() {
    this.setupAutoFormatting();
  }

  private formatCPF(value: string): string {
    const numbers = value.replace(/\D/g, '');
    const limited = numbers.substring(0, 11);

    if (limited.length <= 3) {
      return limited;
    } else if (limited.length <= 6) {
      return limited.replace(/(\d{3})(\d+)/, '$1.$2');
    } else if (limited.length <= 9) {
      return limited.replace(/(\d{3})(\d{3})(\d+)/, '$1.$2.$3');
    } else {
      return limited.replace(/(\d{3})(\d{3})(\d{3})(\d{0,2})/, '$1.$2.$3-$4');
    }
  }

  private setupAutoFormatting() {
    this.pixTransferForm.get('received')?.valueChanges.subscribe(value => {
      if (!value) return;

      const formatted = this.formatCPF(value);

      if (formatted !== value) {
        this.pixTransferForm.get('received')?.setValue(formatted, {
          emitEvent: false
        });
      }
    });
  }

  sendPix() {
    this.pixService.pixTransfer(
      this.pixTransferForm.value.received!,
      this.pixTransferForm.value.value!
    );
  }
}
