import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CreateAccountService } from '../../services/create-account-service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './register.html',
  styleUrl: './register.css',
})
export class Register {

  constructor(
    private router: Router,
    private registerService: CreateAccountService
  ){

  }


  registerForm = new FormGroup({
    name: new FormControl('', [
      Validators.required,
      Validators.minLength(3),
      Validators.maxLength(100)
    ]),

    cpf: new FormControl('', [
      Validators.required,
      Validators.pattern(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/)
    ]),

    email: new FormControl('', [
      Validators.required,
      Validators.email
    ]),

    phone: new FormControl('', [
      Validators.required,
      Validators.pattern(/^\(\d{2}\) \d{5}-\d{4}$/)
    ]),

    password: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/)
    ]),

    confimPassword: new FormControl('', [
      Validators.required
    ]),

    checkbox: new FormControl(false, [
      Validators.requiredTrue
    ])
  });

  ngOnInit() {
    this.setupAutoFormatting();
  }

  private setupAutoFormatting() {
    // Formatação automática do CPF
    this.registerForm.get('cpf')?.valueChanges.subscribe(value => {
      if (value) {
        const formatted = this.formatCPF(value);
        if (formatted !== value) {
          this.registerForm.get('cpf')?.setValue(formatted, { emitEvent: false });
        }
      }
    });

    // Formatação automática do telefone
    this.registerForm.get('phone')?.valueChanges.subscribe(value => {
      if (value) {
        const formatted = this.formatPhone(value);
        if (formatted !== value) {
          this.registerForm.get('phone')?.setValue(formatted, { emitEvent: false });
        }
      }
    });
  }

  private formatCPF(value: string): string {
    // Remove tudo que não é número
    const numbers = value.replace(/\D/g, '');

    // Limita a 11 dígitos
    const limited = numbers.substring(0, 11);

    // Aplica a formatação
    if (limited.length <= 3) {
      return limited;
    } else if (limited.length <= 6) {
      return limited.replace(/(\d{3})(\d{0,3})/, '$1.$2');
    } else if (limited.length <= 9) {
      return limited.replace(/(\d{3})(\d{3})(\d{0,3})/, '$1.$2.$3');
    } else {
      return limited.replace(/(\d{3})(\d{3})(\d{3})(\d{0,2})/, '$1.$2.$3-$4');
    }
  }

  private formatPhone(value: string): string {
    // Remove tudo que não é número
    const numbers = value.replace(/\D/g, '');

    // Limita a 11 dígitos
    const limited = numbers.substring(0, 11);

    // Aplica a formatação
    if (limited.length === 0) {
      return '';
    } else if (limited.length <= 2) {
      return `(${limited}`;
    } else if (limited.length <= 7) {
      return limited.replace(/(\d{2})(\d{0,5})/, '($1) $2');
    } else {
      return limited.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3');
    }
  }

  // Método para enviar o formulário
  register() {
    if (this.registerForm.valid) {
    this.registerService
      .register(this.registerForm.value.name!, 
                this.registerForm.value.cpf!,
                this.registerForm.value.phone!,
                this.registerForm.value.email!,
                this.registerForm.value.password!)
    
    this.registerForm.reset
  
    this.router.navigateByUrl('/')

    } else {
      console.log('Formulário inválido');
      // Marca todos os campos como tocados para mostrar erros
    }
  }

}


