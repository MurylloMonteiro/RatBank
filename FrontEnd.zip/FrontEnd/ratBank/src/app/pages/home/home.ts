import { Component } from '@angular/core';
import { Balance } from "../../components/balance/balance";
import { History } from "../../components/history/history";
import { Shortcuts } from "../../components/shortcuts/shortcuts";
import { Footer } from "../../components/footer/footer";

@Component({
  selector: 'app-home',
  imports: [Balance, History, Shortcuts, Footer],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {
  infos: any = JSON.parse(sessionStorage.getItem("User")!);

}
