import { Component } from '@angular/core';
import { PixSend } from "../../components/pix-send/pix-send";
import { Footer } from "../../components/footer/footer";
import { PixKeys } from "../../components/pix-keys/pix-keys";

@Component({
  selector: 'app-pix-area',
  imports: [PixSend, Footer, PixKeys],
  templateUrl: './pix-area.html',
  styleUrl: './pix-area.css',
})
export class PixArea {

}
