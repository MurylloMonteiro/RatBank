import { Component } from '@angular/core';

@Component({
  selector: 'app-deposit',
  imports: [],
  templateUrl: './deposit.html',
  styleUrl: './deposit.css',
})
export class Deposit {

}
