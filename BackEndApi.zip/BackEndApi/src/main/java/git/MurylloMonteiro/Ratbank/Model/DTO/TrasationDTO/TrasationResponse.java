package git.MurylloMonteiro.Ratbank.Model.DTO.TrasationDTO;

public class TrasationResponse {

}
