package git.MurylloMonteiro.Ratbank.Model.DTO.LoginDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginResponse {

    private String token;

}
