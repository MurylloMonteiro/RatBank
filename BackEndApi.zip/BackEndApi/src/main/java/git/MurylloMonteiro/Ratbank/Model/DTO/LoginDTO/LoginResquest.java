package git.MurylloMonteiro.Ratbank.Model.DTO.LoginDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginResquest {

    private String email;
    private String password;

}
