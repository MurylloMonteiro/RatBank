package git.MurylloMonteiro.Ratbank.Model.DTO.DepositDTO;

public class DepositRequest {

}
