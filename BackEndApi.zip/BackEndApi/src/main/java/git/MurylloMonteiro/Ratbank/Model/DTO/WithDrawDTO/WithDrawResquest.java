package git.MurylloMonteiro.Ratbank.Model.DTO.WithDrawDTO;

public class WithDrawResquest {

}
