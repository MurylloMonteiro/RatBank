package git.MurylloMonteiro.Ratbank.Model.DTO.Account;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class AccountResponse {

    private String numberAccount;
    private String pixkey;

}
