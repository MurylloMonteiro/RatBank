package git.MurylloMonteiro.Ratbank.Repository;

public interface TrasationRepository {

    
}
